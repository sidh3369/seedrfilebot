
DROP INDEX idx_seedr_accounts_active;
DROP INDEX idx_seedr_accounts_user_id;
DROP TABLE seedr_accounts;
