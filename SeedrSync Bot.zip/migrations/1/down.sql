
DROP INDEX idx_users_telegram_user_id;
DROP TABLE users;
